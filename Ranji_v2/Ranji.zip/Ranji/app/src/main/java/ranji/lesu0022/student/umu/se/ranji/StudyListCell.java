package ranji.lesu0022.student.umu.se.ranji;

import android.content.Context;
import android.widget.LinearLayout;
import android.widget.TextView;

import ranji.lesu0022.student.umu.se.ranji.Data.Kanji;

/**
 * Created by leifthysellsundqvist on 2017-08-15.
 */

public class StudyListCell extends LinearLayout {

    private TextView tv_name;

    public StudyListCell(Context context) {
        super(context);
        init();
    }

    private void init() {
        inflate(getContext(), R.layout.cell_studylist, this);
        tv_name = findViewById(R.id.tv_studylist_name);
    }

    public TextView getTv_name() {
        return tv_name;
    }
}
