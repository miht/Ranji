package ranji.lesu0022.student.umu.se.ranji.Data;

import java.io.Serializable;

/**
 * Created by leifthysellsundqvist on 2017-08-15.
 *
 * THe kanji class represents a kanji character. Serialisability enables me to send the kanji objects through intents.
 */

public class Kanji implements Serializable {
    private String character = "";
    private String translation = "";
    private String onyomi = "";
    private String kunyomi ="";

    public Kanji(String character, String translation, String onyomi, String kunyomi) {
        this.character = character;
        this.translation = translation;
        this.onyomi = onyomi;
        this.kunyomi = kunyomi;
    }

    public String getCharacter() {
        return character;
    }

    public String getMeaning() {
        return translation;
    }

    public String getOnyomi() {
        return onyomi;
    }

    public String getKunyomi() {
        return kunyomi;
    }

}
