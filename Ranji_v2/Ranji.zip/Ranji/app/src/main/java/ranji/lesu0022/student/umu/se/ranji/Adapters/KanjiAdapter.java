package ranji.lesu0022.student.umu.se.ranji.Adapters;

import android.content.Context;
import android.database.Cursor;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CursorAdapter;
import android.widget.TextView;

import ranji.lesu0022.student.umu.se.ranji.KanjiCell;
import ranji.lesu0022.student.umu.se.ranji.StudyListCell;

/**
 * Created by leifthysellsundqvist on 2017-08-15.
 */

public class KanjiAdapter extends CursorAdapter {

    private Context context;

    public KanjiAdapter(Context context, Cursor cursor) {
        super(context, cursor, 0);
        this.context = context;
    }

    // The newView method is used to inflate a new view and return it,
    // you don't bind any data to the view at this point.
    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        return new KanjiCell(context);
    }

    // The bindView method is used to bind all data to a given view
    // such as setting the text on a TextView.
    @Override
    public void bindView(View view, Context context, Cursor cursor) {
        String name = cursor.getString(cursor.getColumnIndexOrThrow("_id"));
        String kunyomi = cursor.getString(cursor.getColumnIndexOrThrow("KUNYOMI"));
        String onyomi = cursor.getString(cursor.getColumnIndexOrThrow("ONYOMI"));
        String meaning = cursor.getString(cursor.getColumnIndexOrThrow("TRANSLATION"));

        KanjiCell kc = (KanjiCell) view;

        kc.getTv_character().setText(name);
        kc.getTv_onyomi().setText(onyomi);
        kc.getTv_kunyomi().setText(kunyomi);
        kc.getTv_meaning().setText(meaning);
    }

}
