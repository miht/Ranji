package ranji.lesu0022.student.umu.se.ranji.Data;


import android.content.Context;
import android.util.Log;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

import ranji.lesu0022.student.umu.se.ranji.KanjiDatabaseHelper;

/**
 * Created by leifthysellsundqvist on 2017-08-20.
 *
 * Singleton class responsible for the game-related mechanics of the application, such as fetching new
 * questions and alternatives, and keeping track of the user score.
 */

public class Game implements Serializable {

    private Context context;

    private KanjiDatabaseHelper db;

    private int round = 0;
    private int score = 0;

    private Random rand;

    private ArrayList<Kanji> kanjis;

    private ArrayList<Kanji> alternatives;

    private Kanji correctKanji;

    public Game(Context context) {
        this.context = context;
        db = KanjiDatabaseHelper.getInstance(context);
        kanjis =  new ArrayList<>();
        alternatives = new ArrayList<>();

        rand = new Random();
    }

    public void generateAlternatives() {
        Log.d("TEST", "Generating alternatives.");
        alternatives = new ArrayList<>();
        //Add a random kanji. This will be the answer kanji
        alternatives.add(kanjis.get(rand.nextInt(kanjis.size())));
        correctKanji = alternatives.get(0);

        //as for the remaining three kanji, randomize each one until its unique in the list, and add it.
        for(int i = 1; i < 4; i++) {
            Kanji kan = kanjis.get(rand.nextInt(kanjis.size()));
            while(alternatives.contains(kan)) {
                kan = kanjis.get(rand.nextInt(kanjis.size()));
            }
            alternatives.add(kan);
        }
        //Assert that all the alternatives are random
        Collections.shuffle(alternatives);
        Log.d("TEST", "Generated alternatives.");
    }

    public ArrayList<Kanji> getAlternatives() {
        return alternatives;
    }

    public Kanji getAnswer() {
        return correctKanji;
    }

    public int getRound() {
        return round;
    }

    public void setRound(int round) {
        this.round = round;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public ArrayList<Kanji> getKanjis() {
        return kanjis;
    }

    public void setKanjis(ArrayList<Kanji> kanjis) {
        this.kanjis = kanjis;
    }
}
