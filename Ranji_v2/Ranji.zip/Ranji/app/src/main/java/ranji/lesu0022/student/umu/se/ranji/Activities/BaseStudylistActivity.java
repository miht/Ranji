package ranji.lesu0022.student.umu.se.ranji.Activities;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.PorterDuff;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.InputType;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;


import com.wdullaer.swipeactionadapter.SwipeActionAdapter;
import com.wdullaer.swipeactionadapter.SwipeDirection;

import ranji.lesu0022.student.umu.se.ranji.Adapters.StudylistAdapter;
import ranji.lesu0022.student.umu.se.ranji.KanjiDatabaseHelper;
import ranji.lesu0022.student.umu.se.ranji.R;

/**
 * Created by leifthysellsundqvist on 2017-08-17.
 *
 * This class serves as the base activity for the lists showing study lists within the application.
 *
 * I added swipe-to-delete functionality (credits to git user wdullaer's SwipeActionAdapter), because I think that
 * this type of functionality is self-explanatory and familiar to most smartphone users.
 */

public class BaseStudylistActivity extends AppCompatActivity {
    protected KanjiDatabaseHelper db;

    protected ListView lv_studyLists;
    protected StudylistAdapter sla;
    protected SwipeActionAdapter mAdapter;

    private ImageView iv_no_studylists_pusheen;

    private Button btn_create_studylist;

    public static final String BUNDLE_IS_SHOWING_DIALOG ="Is_showing_dialog";
    private boolean isShowingDialog = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_studylists);

        db = KanjiDatabaseHelper.getInstance(this);

        Cursor cur  = db.getStudyLists();
        sla = new StudylistAdapter(this, cur);

        lv_studyLists = (ListView) findViewById(R.id.lv_studylists);
        lv_studyLists.setAdapter(sla);

        if(savedInstanceState != null) {
            if(savedInstanceState.getBoolean(BUNDLE_IS_SHOWING_DIALOG, false)) {

            }
        }

        initSwipeActionAdapter();

        initEmptyView();
        lv_studyLists.setEmptyView(findViewById(R.id.ll_no_studylists));
    }

    @Override
    public void onResume() {

        super.onResume();
        sla.changeCursor(db.getStudyLists());
        sla.notifyDataSetChanged();
        mAdapter.notifyDataSetChanged();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.studylists_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.action_add_studylist:
                DialogFragment newFragment = StudyListAlertDialogFragment.newInstance();
                newFragment.show(getSupportFragmentManager(), "dialog");
                //showCreateStudylistDialog();
                break;
            default:
                return super.onOptionsItemSelected(item);
        }
        return true;
    }

    private void initSwipeActionAdapter() {

        mAdapter = new SwipeActionAdapter(sla);
        mAdapter.setListView(lv_studyLists);
        lv_studyLists.setAdapter(mAdapter);
        mAdapter.setFarSwipeFraction(1);

        // Set backgrounds for the swipe directions
        mAdapter.addBackground(SwipeDirection.DIRECTION_NORMAL_LEFT,R.layout.row_bg_left_far);


    }

    private void initEmptyView() {
        iv_no_studylists_pusheen = (ImageView) findViewById(R.id.iv_no_studylists_pusheen);
        iv_no_studylists_pusheen.setBackgroundResource(R.drawable.pusheen_detective_animation1);
        AnimationDrawable frameAnimation = (AnimationDrawable) iv_no_studylists_pusheen.getBackground();

        // Start the animation (looped playback by default).
        frameAnimation.start();

        btn_create_studylist = (Button) findViewById(R.id.btn_create_studylist);
        btn_create_studylist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DialogFragment newFragment = StudyListAlertDialogFragment.newInstance();
                newFragment.show(getSupportFragmentManager(), "dialog");
                //showCreateStudylistDialog();
            }
        });
    }

    public void updateLists() {
        Log.d("UPDATE", "Updating lists");
        sla.changeCursor(db.getStudyLists());
        sla.notifyDataSetChanged();
        mAdapter.notifyDataSetChanged();
    }

    /**
     * display a dialog with a search field, so that the user may specify a name for the new study list
     * that will be created.
     */
    public void showCreateStudylistDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this, R.style.CustomAlertDialog);

        // Set up the input
        final EditText input = new EditText(this);
        input.getBackground().mutate().setColorFilter(ContextCompat.getColor(this, R.color.colorPrimary), PorterDuff.Mode.SRC_ATOP);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        params.setMargins(20, 0, 20, 0);

        input.setInputType(InputType.TYPE_CLASS_TEXT);

        layout.addView(input, params);
        builder.setView(layout);

        builder.setTitle("New Studylist");

        // Set up the buttons
        builder.setPositiveButton("Done", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                db.insertStudyList(input.getText().toString());

                //refresh the cursor after database action
                sla.changeCursor(db.getStudyLists());
                sla.notifyDataSetChanged();
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.show();
        mAdapter.notifyDataSetChanged();
    }

    public static class StudyListAlertDialogFragment extends DialogFragment {
        public static final String BUNDLE_INPUT_STRING = "Bundle_input_string";

        private EditText input;

        public static StudyListAlertDialogFragment newInstance() {
            StudyListAlertDialogFragment frag = new StudyListAlertDialogFragment();
            return frag;
        }

        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {


            // Set up the input
            input = new EditText(getContext());
            input.getBackground().mutate().setColorFilter(ContextCompat.getColor(getContext(), R.color.colorPrimary), PorterDuff.Mode.SRC_ATOP);

            if(savedInstanceState != null) {
                input.setText(savedInstanceState.getString(BUNDLE_INPUT_STRING));
            }

            LinearLayout layout = new LinearLayout(getContext());
            layout.setOrientation(LinearLayout.VERTICAL);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            params.setMargins(20, 0, 20, 0);

            input.setInputType(InputType.TYPE_CLASS_TEXT);

            layout.addView(input, params);

            return new AlertDialog.Builder(getActivity(), R.style.CustomAlertDialog)
                    .setTitle("New Studylist")
                    .setView(layout)
                    .setPositiveButton("Done", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            KanjiDatabaseHelper.getInstance(getContext()).insertStudyList(input.getText().toString());
                            ((BaseStudylistActivity)getActivity()).updateLists();
                        }
                    })
            .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.cancel();
                }
            }).create();
        }

        @Override
        public void onSaveInstanceState(Bundle outState) {
            outState.putString(BUNDLE_INPUT_STRING, input.getText().toString());
            super.onSaveInstanceState(outState);
        }
    }
}