package ranji.lesu0022.student.umu.se.ranji.Activities;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.PorterDuff;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.InputType;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;

import com.wdullaer.swipeactionadapter.SwipeActionAdapter;
import com.wdullaer.swipeactionadapter.SwipeDirection;

import ranji.lesu0022.student.umu.se.ranji.Adapters.StudylistAdapter;
import ranji.lesu0022.student.umu.se.ranji.KanjiDatabaseHelper;
import ranji.lesu0022.student.umu.se.ranji.R;
import ranji.lesu0022.student.umu.se.ranji.StudyListCell;

/**
 * Created by leifthysellsundqvist on 2017-08-15.
 *
 * Shows a list of all study lists created to the user, and also allows him/her to create new ones.
 *
 * within this activity, the user may delete list items by swiping to the left, as defined by
 * the SwipeActionListener by git user wdullaer.
 */

public class StudylistsActivity extends BaseStudylistActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Listen to swipes
        mAdapter.setSwipeActionListener(new SwipeActionAdapter.SwipeActionListener(){
            @Override
            public boolean hasActions(int position, SwipeDirection direction){
                if(direction.isLeft()) return true; // Change this to false to disable left swipes
                return false;
            }

            @Override
            public boolean shouldDismiss(int position, SwipeDirection direction){
                // Only dismiss an item when swiping normal left
                return direction == SwipeDirection.DIRECTION_NORMAL_LEFT;
            }

            @Override
            public void onSwipe(int[] positionList, SwipeDirection[] directionList){
                for(int i=0;i<positionList.length;i++) {
                    SwipeDirection direction = directionList[i];
                    int position = positionList[i];
                    String dir = "";

                    switch (direction) {
                        case DIRECTION_NORMAL_LEFT:
                            dir = "Far left";
                            sla.getCursor().moveToPosition(position);
                            db.removeStudyList(sla.getCursor().getString(0));
                            sla.changeCursor(db.getWritableDatabase().rawQuery("SELECT * FROM " + KanjiDatabaseHelper.TABLE_STUDYLISTS, null));
                            sla.notifyDataSetChanged();
                            break;
                    }
                    mAdapter.notifyDataSetChanged();
                }
            }
        });

        lv_studyLists.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                showStudyListKanjiActivity(sla.getCursor().getString(0));
            }
        });
    }

    private void showStudyListKanjiActivity(String searchword) {
        Intent intent = new Intent(this, KanjiListActivity.class);
        intent.putExtra(KanjiListActivity.CURRENT_STUDYLIST_EXTRA, searchword);
        startActivity(intent);
    }
}
