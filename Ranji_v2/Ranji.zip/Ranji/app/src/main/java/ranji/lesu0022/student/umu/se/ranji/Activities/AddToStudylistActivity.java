package ranji.lesu0022.student.umu.se.ranji.Activities;

import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.InputType;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;


import ranji.lesu0022.student.umu.se.ranji.Adapters.StudylistAdapter;
import ranji.lesu0022.student.umu.se.ranji.Data.Kanji;
import ranji.lesu0022.student.umu.se.ranji.Data.Structs;
import ranji.lesu0022.student.umu.se.ranji.KanjiDatabaseHelper;
import ranji.lesu0022.student.umu.se.ranji.R;

/**
 * Created by leifthysellsundqvist on 2017-08-15.
 *
 * This view is shown whenever the user wants to add a specific kanji to a created study list.
 *
 * The current kanji is sent to this activity using an intent extra
 *
 *
 */

public class AddToStudylistActivity extends BaseStudylistActivity {

    public static final String ADD_TO_STUDYLIST_EXTRA = "Add_to_studylist_extra";

    private Kanji kanji;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        kanji = (Kanji) getIntent().getSerializableExtra(ADD_TO_STUDYLIST_EXTRA);

        lv_studyLists.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                //Get the _id (kanji character) column from the kanji table within the database
                addToStudylist(sla.getCursor().getString(0));
                sla.notifyDataSetChanged();
                mAdapter.notifyDataSetChanged();
            }
        });
    }

    void addToStudylist(String studylist) {
        //We don't want to add kanjis to a study list if they already exist
        if(!db.existsKanji(kanji, studylist)) {
            db.insertKanji(kanji, studylist);
            finish();
        }
        else {
            Structs.generatePopup(this, "Error", "This list already contains this kanji.");
        }
    }
}
