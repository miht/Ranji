package ranji.lesu0022.student.umu.se.ranji.Activities;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import ranji.lesu0022.student.umu.se.ranji.Data.Kanji;
import ranji.lesu0022.student.umu.se.ranji.KanjiDatabaseHelper;
import ranji.lesu0022.student.umu.se.ranji.R;

/**
 * Created by leifthysellsundqvist on 2017-08-20.
 *
 * This activity shows the user the photo related to the selected kanji, and also allows him/her to change the photo by
 * either selecting a new one from the gallery, or by taking a new one using the camera. this means that
 * we'll have to deal with permissions. the permissions i'm working with are READ_EXTERNAL_STORAGE and CAMERA.
 *
 */

public class ShowImageActivity extends AppCompatActivity {
    public static final String KANJI_EXTRA = "Kanji_extra";

    private static final int REQUEST_IMAGE_PICK = 0;
    private static final int REQUEST_IMAGE_CAPTURE = 1;
    private static final int REQUEST_IMAGE_REFRESH = 2;

    private Kanji kanji;

    private Button btn_changeimage;
    private ImageView iv_image;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.show_image_activity);

        kanji = (Kanji) getIntent().getSerializableExtra(KANJI_EXTRA);

        initViews();
    }

    private void initViews() {
        btn_changeimage = (Button) findViewById(R.id.btn_changeimage);
        btn_changeimage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showChangeImageDialog();
            }
        });
        iv_image = (ImageView) findViewById(R.id.iv_image);

        getImage(Manifest.permission.READ_EXTERNAL_STORAGE, REQUEST_IMAGE_REFRESH);
    }

    /**
     * Dialog asking the user whether he/she wants to use an image from the gallery or take a new one.
     */
    public void showChangeImageDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this, R.style.CustomAlertDialog);
        builder.setTitle("New image");

        // Set up the buttons
        builder.setPositiveButton("Camera", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA)) {
                    getImage(Manifest.permission.CAMERA, REQUEST_IMAGE_CAPTURE);
                } else {

                }
            }
        });

        builder.setNegativeButton("Gallery", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                getImage(Manifest.permission.READ_EXTERNAL_STORAGE, REQUEST_IMAGE_PICK);
            }
        });
        builder.setNeutralButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        builder.show();
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            Bitmap imageBitmap = (Bitmap) extras.get("data");

            Uri tempUri = getImageUri(getApplicationContext(), imageBitmap);
            iv_image.setImageURI(tempUri);
            insertImage(tempUri);
        } else if (requestCode == REQUEST_IMAGE_PICK && resultCode == RESULT_OK) {
            Uri selectedImage = data.getData();
            Log.d("Get image", "Getting image from DB (URI: " + selectedImage);
            iv_image.setImageURI(selectedImage);
            insertImage(selectedImage);
        }
    }

    public void refreshImage() {
        Log.d("REFRESH IMAGE", "Starting to refresh image");

        Bitmap image = null;
        Uri uri = KanjiDatabaseHelper.getInstance(this).fetchImage(kanji.getCharacter());

        if (uri.toString().trim().length() < 1) {
            return;
        }

        try {
            image = MediaStore.Images.Media.getBitmap(this.getContentResolver(), uri);
            iv_image.setImageBitmap(image);

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Insert the images' file path into the database for the current kanji
     * @param uri
     */
    public void insertImage(Uri uri) {
        KanjiDatabaseHelper.getInstance(this).insertImage(kanji.getCharacter(), uri);
    }

    /**
     * Extract the URI from a given bitmap image.
     * @param inContext
     * @param inImage
     * @return the URI of inImage
     */
    public Uri getImageUri(Context inContext, Bitmap inImage) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        String path = MediaStore.Images.Media.insertImage(getContentResolver(), inImage, "Title", null);
        return Uri.parse(path);
    }

    private void goToScreenCapture() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
        }
    }

    private void goToGalleryPicker() {
        //read from gallery here
        Intent pickPhoto = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(pickPhoto, REQUEST_IMAGE_PICK);//one can be replaced with any action code
    }

    /**
     * whenever we want to use or fetch an image from the gallery or camera, we need permissions, so we ask the user for them.
     * @param perm
     * @param requestCode
     */
    private void getImage(String perm, int requestCode) {
        if (ContextCompat.checkSelfPermission(this,
                perm) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this,
                    new String[]{perm},
                    requestCode);
        } else {
            switch (requestCode) {
                case REQUEST_IMAGE_CAPTURE:
                    goToScreenCapture();
                    break;
                case REQUEST_IMAGE_PICK:
                    goToGalleryPicker();
                    break;
                case REQUEST_IMAGE_REFRESH:
                    refreshImage();
                    break;
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        if (grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

            // permission granted. noice; proceed!

            switch (requestCode) {
                case REQUEST_IMAGE_PICK: {
                    goToGalleryPicker();
                    break;
                }
                case REQUEST_IMAGE_CAPTURE: {
                    //use camera here
                    goToScreenCapture();
                    break;
                }

                case REQUEST_IMAGE_REFRESH: {
                    refreshImage();
                    break;
                }
            }
        }
    }
}