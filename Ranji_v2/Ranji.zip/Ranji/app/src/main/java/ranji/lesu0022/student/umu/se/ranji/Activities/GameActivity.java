package ranji.lesu0022.student.umu.se.ranji.Activities;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.BundleCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.TextView;

import java.util.ArrayList;

import ranji.lesu0022.student.umu.se.ranji.Data.Game;
import ranji.lesu0022.student.umu.se.ranji.Data.Kanji;
import ranji.lesu0022.student.umu.se.ranji.KanjiDatabaseHelper;
import ranji.lesu0022.student.umu.se.ranji.R;

/**
 * Created by leifthysellsundqvist on 2017-08-20.
 */

public class GameActivity extends AppCompatActivity {

    public final static String GAME_STUDYLIST_EXTRA = "Game_studylist_extra";
    public final static String BUNDLE_KEY_GAME = "Bundle_key_game";

    private KanjiDatabaseHelper db;

    private TextView tv_kanji;

    //This gridlayout is comprised of the four alternative-buttons
    private GridLayout gl_buttons;
    private TextView tv_score;
    private Button btn_skip;

    //The game object, responsible for score, points, etc.
    private Game game;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play);

        setTitle("Practice");

        Intent i = getIntent();
        String studylist = i.getStringExtra(GAME_STUDYLIST_EXTRA);

        db = KanjiDatabaseHelper.getInstance(this);
        Cursor cur  = db.fetchKanjiWithinStudylist(studylist);

        ArrayList<Kanji> kanjis = new ArrayList<>();
        for(cur.moveToFirst(); !cur.isAfterLast(); cur.moveToNext()) {
            Kanji kan = new Kanji(cur.getString(0), cur.getString(1), cur.getString(2), cur.getString(3));

            kanjis.add(kan);
        }

        initViews();

        if(savedInstanceState == null) {
            game = new Game(this);
            game.setKanjis(kanjis);
            game.generateAlternatives();
        }
        else {
            game = (Game) savedInstanceState.getSerializable(BUNDLE_KEY_GAME);
        }

        initGameButtons();
        refreshScreen();
    }

    public void initGameButtons() {
        for(int i = 0; i < gl_buttons.getChildCount(); i++) {
            Button b = (Button) gl_buttons.getChildAt(i);
            b.setText(game.getAlternatives().get(i).getMeaning());
            b.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Button but = (Button) view;
                    if(but.getText().equals(game.getAnswer().getMeaning())) {
                        updateScore(1);
                    }
                    else {
                        updateScore(0);
                    }
                    game.generateAlternatives();
                    refreshScreen();
                }
            });
        }
    }

    private void refreshScreen() {
        tv_score.setText("Score: " + game.getScore() + " (" + game.getRound() + ")");
        tv_kanji.setText(game.getAnswer().getCharacter());

        for(int i = 0; i < gl_buttons.getChildCount(); i++) {
            Button b = (Button) gl_buttons.getChildAt(i);
            b.setText(game.getAlternatives().get(i).getMeaning());
        }
    }

    public void initViews() {
        tv_kanji =(TextView) findViewById(R.id.tv_big_kanji);
        gl_buttons = (GridLayout) findViewById(R.id.gl_buttons);
        tv_score = (TextView) findViewById(R.id.tv_score);
        btn_skip = (Button) findViewById(R.id.btn_skip);

        btn_skip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                updateScore(0);
                game.generateAlternatives();
                refreshScreen();
            }
        });
    }

    public void updateScore(int points) {
        game.setScore(game.getScore() + points);
        game.setRound(game.getRound() + 1);
    }

    @Override
    protected void onSaveInstanceState(Bundle savedInstanceState) {

        savedInstanceState.putSerializable(BUNDLE_KEY_GAME, game);
        super.onSaveInstanceState(savedInstanceState);

    }
}
