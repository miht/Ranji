package ranji.lesu0022.student.umu.se.ranji.Activities;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import ranji.lesu0022.student.umu.se.ranji.Data.Kanji;
import ranji.lesu0022.student.umu.se.ranji.KanjiDatabaseHelper;
import ranji.lesu0022.student.umu.se.ranji.R;

/**
 * Created by leifthysellsundqvist on 2017-08-15.
 *
 * This kanji shows the selected kanji with more details such as onyomi, kunyomi, skip and the grade level.
 * furthermore, as required by the assignment, this activity also allows the user to
 * select or take a new photo of something related to the kanji for easier recognition.
 * lastly, the kanji may be added to a study list from this view.
 */

public class ShowKanjiActivity extends AppCompatActivity {
    public static final String KANJI_EXTRA = "Kanji_extra";

    private KanjiDatabaseHelper db;

    private Kanji kanji;

    private RelativeLayout rl_contents;
    private TextView tv_character;
    private TextView tv_meaning;
    private TextView tv_onyomi;
    private TextView tv_kunyomi;
    private LinearLayout ll_attached_image;

    private Button btn_addToStudyList;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.show_kanji_activity);

        db = KanjiDatabaseHelper.getInstance(this);

        Intent i = getIntent();
        kanji = (Kanji) i.getSerializableExtra(KANJI_EXTRA);

        setTitle(kanji.getCharacter() + " - " + kanji.getMeaning());

        initViews();
    }

    private void initViews() {
        rl_contents = (RelativeLayout) findViewById(R.id.rl_contents);
        tv_character = (TextView) findViewById(R.id.tv_kanji);
        tv_meaning = (TextView) findViewById(R.id.tv_meaning);
        tv_onyomi = (TextView) findViewById(R.id.tv_onyomi);
        tv_kunyomi = (TextView) findViewById(R.id.tv_kunyomi);

        tv_character.setText(kanji.getCharacter());
        tv_meaning.setText(kanji.getMeaning());
        tv_onyomi.setText(kanji.getOnyomi());
        tv_kunyomi.setText(kanji.getKunyomi());

        btn_addToStudyList = (Button) findViewById(R.id.btn_addToStudyList);
        btn_addToStudyList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addToStudylistActivity();
            }
        });

        ll_attached_image = (LinearLayout) findViewById(R.id.ll_attached_image);

        ll_attached_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showImageActivity();
                Log.d("Pressed img btn", "Pressed image button");
            }
        });

    }

    private void showImageActivity() {
        Intent intent = new Intent(this, ShowImageActivity.class);
        intent.putExtra(ShowImageActivity.KANJI_EXTRA, kanji);
        startActivity(intent);
    }

    private void addToStudylistActivity() {
        Intent intent = new Intent(this, AddToStudylistActivity.class);
        intent.putExtra(AddToStudylistActivity.ADD_TO_STUDYLIST_EXTRA, kanji);
        startActivity(intent);
    }

    @Override
    public void onBackPressed() {
        finish();
    }
}
