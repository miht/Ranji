package ranji.lesu0022.student.umu.se.ranji;

import android.content.Context;
import android.util.JsonReader;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;
import java.util.ArrayList;

import ranji.lesu0022.student.umu.se.ranji.Data.Kanji;

/**
 * Created by leifthysellsundqvist on 2017-08-14.
 *
 * This class parses a given kanji json file and reads its contents into an arraylist of kanji.
 * for more information, and happy reading, see the "kanji.json" file within the assets folder.
 */

public class JSONParser {
    private static JSONParser instance = null;

    Context context;

    public JSONParser(Context context) {
        this.context = context;
    }

    public ArrayList<Kanji> parse() {
        InputStream is = null;
        JsonReader jr = null;

        try {
            is = context.getAssets().open("kanji.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            String myJson = new String(buffer, "UTF-8");

            return getKanji(myJson);

        } catch (Exception e) {
            // Oops
        }
        finally {
            try{if(jr != null)jr.close();}catch(Exception squish){}
        }
        return null;
    }

    private ArrayList<Kanji> getKanji(String json) throws JSONException{
        JSONArray ja = new JSONArray(json);
        ArrayList<Kanji> kanjis = new ArrayList<>();

        for (int i = 0; i < ja.length(); i++) {
            JSONObject jo = ja.getJSONObject(i);

            JSONObject jo_kanji = new JSONObject(jo.getString("kanji"));

            String kanji_character = jo_kanji.getString("character");

            JSONObject jo_meaning = new JSONObject(jo_kanji.getString("meaning"));
            String kanji_meaning = jo_meaning.getString("english");

            JSONObject jo_onyomi = new JSONObject(jo_kanji.getString("onyomi"));
            String kanji_onyomi = jo_onyomi.getString("katakana");

            JSONObject jo_kunyomi = new JSONObject(jo_kanji.getString("kunyomi"));
            String kanji_kunyomi = jo_kunyomi.getString("hiragana");

            kanjis.add(new Kanji(kanji_character, kanji_meaning, kanji_onyomi, kanji_kunyomi));
        }

        return kanjis;
    }
}
