package ranji.lesu0022.student.umu.se.ranji.Activities;

import android.content.Intent;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.sql.Struct;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import ranji.lesu0022.student.umu.se.ranji.Data.Structs;
import ranji.lesu0022.student.umu.se.ranji.KanjiDatabaseHelper;
import ranji.lesu0022.student.umu.se.ranji.R;

public class MainActivity extends AppCompatActivity {

    //The database object
    private KanjiDatabaseHelper db;

    private EditText et_search_kanji;
    private Button btn_go;
    private Button btn_studylists;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = KanjiDatabaseHelper.getInstance(this);

        initViews();
    }

    private void initViews() {
        et_search_kanji = (EditText) findViewById(R.id.et_search_word);
        et_search_kanji.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
                moveToSearchResultsActivity(et_search_kanji.getText().toString());
               return true;
            }
        });

        btn_go = (Button) findViewById(R.id.btn_go);
        btn_go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String search = et_search_kanji.getText().toString();
                if(search.length() <= 0) {
                   // Structs.generatePopup(MainActivity.this, "Error", "Please provide a search word.");
                    DialogFragment newFragment = Structs.AlertDialogFragment.newInstance("Error", "Please provide a search word.");
                    newFragment.show(getSupportFragmentManager(), "dialog");
                }
                else {
                    String searchword = et_search_kanji.getText().toString().trim();
                    //Pattern p = Pattern.compile("(^[A-Za-z]+$)|(^[\\x3400-\\x4DB5\\x4E00-\\x9FCB\\xF900-\\xFA6A]+$)");
                    Pattern p = Pattern.compile("\\p{L}+");
                    boolean b = p.matcher(searchword.replaceAll("\\s", "").trim()).matches();
                    if(b) {
                        moveToSearchResultsActivity(searchword);
                    }
                    else {
                        //Structs.generatePopup(MainActivity.this, "Error", "The query must consist solely of either characters or kanji");
                        DialogFragment newFragment = Structs.AlertDialogFragment.newInstance("Error", "The query must consist solely of either characters or kanji.");
                        newFragment.show(getSupportFragmentManager(), "dialog");
                    }

                }
            }
        });

        btn_studylists = (Button) findViewById(R.id.btn_show_studylists);
        btn_studylists.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                moveToStudyListActivity();
            }
        });
    }

    private void moveToSearchResultsActivity(String searchword) {
        Intent intent = new Intent(this, KanjiSearchListActivity.class);
        intent.putExtra(KanjiSearchListActivity.SEARCHWORD_EXTRA, searchword);
        startActivity(intent);
    }

    private void moveToStudyListActivity() {
        Intent intent = new Intent(this, StudylistsActivity.class);
        startActivity(intent);
    }
}
