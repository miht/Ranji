package ranji.lesu0022.student.umu.se.ranji;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.util.Log;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.net.URI;
import java.nio.ByteBuffer;
import java.util.ArrayList;

import ranji.lesu0022.student.umu.se.ranji.Data.Kanji;

/**
 * Created by leifthysellsundqvist on 2017-08-14.
 */

public class KanjiDatabaseHelper extends SQLiteOpenHelper {

    private static KanjiDatabaseHelper instance = null;

    private JSONParser jp;

    public static final String DATABASE_NAME = "Kanji.db";
    public static final String TABLE_KANJI = "Kanji_table";
    public static final String TABLE_STUDYLISTS = "StudyLists_table";
    public static final String TABLE_STUDYLIST_HAS_KANJI = "StudyList_has_kanji_table";
    public static final String TABLE_KANJI_HAS_IMAGE = "Kanji_has_image_table";

    public static final String KANJI_COL_1 = "_id";
    public static final String KANJI_COL_2 = "TRANSLATION";
    public static final String KANJI_COL_3 = "ONYOMI";
    public static final String KANJI_COL_4 = "KUNYOMI";

    public static final String STUDYLIST_COL_1 = "_id";

    public static final String STUDYLIST_HAS_KANJI_COL_1 = "STUDYLIST";
    public static final String STUDYLIST_HAS_KANJI_COL_2 = "KANJI";

    public static final String KANJI_HAS_IMAGE_COL1 = "KANJI";
    public static final String KANJI_HAS_IMAGE_COL2 = "PATH";

    protected KanjiDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
        jp = new JSONParser(context);
    }

    public static KanjiDatabaseHelper getInstance(Context context) {
        if(instance == null) {
            instance = new KanjiDatabaseHelper(context);
        }
        return instance;
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE " + TABLE_KANJI + " (_id TEXT PRIMARY KEY, TRANSLATION TEXT, ONYOMI TEXT, KUNYOMI TEXT)");
        sqLiteDatabase.execSQL("CREATE TABLE " + TABLE_STUDYLISTS + " (_id TEXT PRIMARY KEY)");
        sqLiteDatabase.execSQL("CREATE TABLE " + TABLE_STUDYLIST_HAS_KANJI + " (STUDYLIST TEXT, KANJI TEXT, PRIMARY KEY(STUDYLIST, KANJI))");
        sqLiteDatabase.execSQL("CREATE TABLE " + TABLE_KANJI_HAS_IMAGE + " (KANJI TEXT PRIMARY KEY, PATH TEXT)");

        //Load all kanji from parser
        for(Kanji kan : jp.parse()) {
            addKanji(kan, sqLiteDatabase);
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    private void addKanji(Kanji kan, SQLiteDatabase sqLiteDatabase) {
        ContentValues cv = new ContentValues();
        cv.put(KANJI_COL_1, kan.getCharacter());
        cv.put(KANJI_COL_2, kan.getMeaning());
        cv.put(KANJI_COL_3, kan.getOnyomi());
        cv.put(KANJI_COL_4, kan.getKunyomi());
        sqLiteDatabase.insert(TABLE_KANJI, null, cv);

        ContentValues cv2 = new ContentValues();
        cv.put(KANJI_HAS_IMAGE_COL1, kan.getCharacter());
        cv.put(KANJI_HAS_IMAGE_COL2, "");
        sqLiteDatabase.insert(TABLE_KANJI_HAS_IMAGE, null, cv2);
    }

    /**
     * Check if a kanji exists within a given study list
     * @param kanji
     * @param studylist
     * @return true if kanji exists in studylist, false otherwise
     */
    public boolean existsKanji(Kanji kanji, String studylist) {
        String query = "SELECT * FROM " + TABLE_STUDYLIST_HAS_KANJI + " WHERE STUDYLIST = '" + studylist + "' AND KANJI ='" + kanji.getCharacter() +"';";
        Cursor cursor = getReadableDatabase().rawQuery(query, null);

        if(cursor.getCount() <= 0){
            cursor.close();
            return false;
        }
        cursor.close();
        return true;
    }

    public void insertKanji(Kanji kanji, String studylist) {
        ContentValues cv = new ContentValues();
        cv.put(STUDYLIST_HAS_KANJI_COL_1, studylist);
        cv.put(STUDYLIST_HAS_KANJI_COL_2, kanji.getCharacter());
        getWritableDatabase().insert(TABLE_STUDYLIST_HAS_KANJI, null, cv);
    }

    /**
     * return all kanji within a given study list
     * @param studylist
     * @return all kanji within the study list
     */
    public Cursor fetchKanjiWithinStudylist(String studylist) {
        String query = "SELECT " + TABLE_KANJI + "." + KANJI_COL_1 +", "  + KANJI_COL_2 + ", "  + KANJI_COL_3 + ", "  + KANJI_COL_4
                + " FROM " + TABLE_KANJI + " INNER JOIN " + TABLE_STUDYLIST_HAS_KANJI
                    + " ON " + TABLE_STUDYLIST_HAS_KANJI + "." + STUDYLIST_HAS_KANJI_COL_2 + "=" + TABLE_KANJI + "." + KANJI_COL_1
                + " WHERE " + STUDYLIST_HAS_KANJI_COL_1 + "='" + studylist + "';";
        Cursor cursor = getReadableDatabase().rawQuery(query, null);


        return cursor;
    }

    /**
     * @param searchWord
     * @return all kanji with either character matching search word or with a meaning matching the search word.
     */
    public Cursor fetchKanji(String searchWord) {
        String query = "SELECT * FROM " + TABLE_KANJI + " " +
                "WHERE " + KANJI_COL_1 + "='" + searchWord + "' " +
                "OR " + KANJI_COL_2 + " LIKE '% " + searchWord + " %'" +
                "OR " + KANJI_COL_2 + " LIKE '" + searchWord + " %'" +
                "OR " + KANJI_COL_2 + " LIKE '% " + searchWord + "'" +
                "OR " + KANJI_COL_2 + " LIKE '" + searchWord + "'" +
                ";";
        Cursor cursor = getReadableDatabase().rawQuery(query, null);

        return cursor;
    }

    public boolean insertStudyList(String studyListName) {
        try {
            ContentValues cv = new ContentValues();
            cv.put(KanjiDatabaseHelper.STUDYLIST_COL_1, studyListName);
            getWritableDatabase().insert(KanjiDatabaseHelper.TABLE_STUDYLISTS, null, cv);

            return true;
        }
        catch(SQLiteException e) {
            return false;
        }
    }

    public void removeStudyList(String studyListName) {
        try {
            getReadableDatabase().execSQL("DELETE FROM " +
                    TABLE_STUDYLISTS + " WHERE " +
                    STUDYLIST_COL_1 + "='" + studyListName + "'");

            getReadableDatabase().execSQL("DELETE FROM " + TABLE_STUDYLIST_HAS_KANJI + " WHERE " + STUDYLIST_HAS_KANJI_COL_1 +" ='" + studyListName +"';");
        }
        catch(SQLiteException e) {
        }
    }

    public void insertImage(String kanji, Uri path) {
        ContentValues cv = new  ContentValues();
        cv.put(KANJI_HAS_IMAGE_COL1, kanji);
        cv.put(KANJI_HAS_IMAGE_COL2, path.toString());
        getWritableDatabase().replace(TABLE_KANJI_HAS_IMAGE, null, cv);
    }

    public Uri fetchImage(String kanji) {
        String query = "SELECT PATH FROM " + TABLE_KANJI_HAS_IMAGE + " " +
                "WHERE " + KANJI_HAS_IMAGE_COL1 + "='" + kanji + "';";
        String path = "";
        Cursor cursor = getReadableDatabase().rawQuery(query, null);

        if(cursor.moveToFirst()){
            path = cursor.getString(0);
        }
        cursor.close();
        return Uri.parse(path);
    }

    public void removeKanji(String studyListName, String kanji) {
        try {
            getReadableDatabase().execSQL("DELETE FROM " +
                    TABLE_STUDYLIST_HAS_KANJI + " WHERE " +
                    STUDYLIST_HAS_KANJI_COL_1 + "='" + studyListName + "' AND " + STUDYLIST_HAS_KANJI_COL_2 + "='" + kanji + "';");

            getReadableDatabase().execSQL("DELETE FROM " +
                    TABLE_KANJI_HAS_IMAGE + " WHERE " +
                    KANJI_HAS_IMAGE_COL1 + "='" + kanji + ";");
        }
        catch(SQLiteException e) {
        }
    }

    public Cursor getStudyLists() {
        Cursor cursor = getReadableDatabase().rawQuery("SELECT "+ STUDYLIST_COL_1 +" FROM " + TABLE_STUDYLISTS, null);
        ArrayList<String> names = new ArrayList<>();

        return cursor;
    }
}
