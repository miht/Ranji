package ranji.lesu0022.student.umu.se.ranji;

import android.content.Context;
import android.widget.LinearLayout;
import android.widget.TextView;

import ranji.lesu0022.student.umu.se.ranji.Data.Kanji;

/**
 * Created by leifthysellsundqvist on 2017-08-15.
 *
 * customised cell for showing kanji within the list activities of the application.
 */

public class KanjiCell extends LinearLayout {

    private TextView tv_character;
    private TextView tv_meaning;
    private TextView tv_onyomi;
    private TextView tv_kunyomi;

    public KanjiCell(Context context) {
        super(context);
        init();
    }

    private void init() {
        inflate(getContext(), R.layout.cell_kanji, this);
        tv_character = findViewById(R.id.tv_cell_kanji);
        tv_meaning =  findViewById(R.id.tv_cell_meaning);
        tv_onyomi = findViewById(R.id.tv_cell_onyomi);
        tv_kunyomi = findViewById(R.id.tv_cell_kunyomi);
    }

    public TextView getTv_character() {
        return tv_character;
    }

    public TextView getTv_meaning() {
        return tv_meaning;
    }

    public TextView getTv_onyomi() {
        return tv_onyomi;
    }

    public TextView getTv_kunyomi() {
        return tv_kunyomi;
    }

}
