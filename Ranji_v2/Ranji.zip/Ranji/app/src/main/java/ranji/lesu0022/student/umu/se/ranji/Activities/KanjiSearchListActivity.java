package ranji.lesu0022.student.umu.se.ranji.Activities;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;

import ranji.lesu0022.student.umu.se.ranji.Data.Kanji;
import ranji.lesu0022.student.umu.se.ranji.KanjiDatabaseHelper;
import ranji.lesu0022.student.umu.se.ranji.R;
import ranji.lesu0022.student.umu.se.ranji.Adapters.KanjiAdapter;

/**
 * Created by leifthysellsundqvist on 2017-08-15.
 *
 * this activity shows a list of all the search results from the search performed by the user within the main menu.
 *
 * unlike in the Kanjilistactivity, the rows within this activity's list view may not be altered or deleted.
 */

public class KanjiSearchListActivity extends AppCompatActivity {

    public static final String SEARCHWORD_EXTRA = "Search_word_extra";

    private String searchword = "";

    private KanjiAdapter ka;

    private KanjiDatabaseHelper db;
    private ListView lv_kanjis;

    private ImageView iv_no_searchresults_pusheen;
    private Button btn_back_to_search;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_results);

        Intent i = getIntent();
        searchword = i.getStringExtra(SEARCHWORD_EXTRA);
        setTitle("Search results for '" + searchword + "'");

        db = KanjiDatabaseHelper.getInstance(this);

        Cursor cur  = db.fetchKanji(searchword);
        ka = new KanjiAdapter(this, cur);

        initListView();
        initEmptyView();
    }

    private void initListView() {
        lv_kanjis = (ListView) findViewById(R.id.lv_search_results);
        lv_kanjis.setAdapter(ka);
        lv_kanjis.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Kanji kan = new Kanji(ka.getCursor().getString(0),  ka.getCursor().getString(1), ka.getCursor().getString(2), ka.getCursor().getString(3));
                showKanjiActivity(kan);
            }
        });

        lv_kanjis.setEmptyView(findViewById(R.id.ll_no_searchresults));
    }

    private void initEmptyView() {
        iv_no_searchresults_pusheen = (ImageView) findViewById(R.id.iv_no_searchresults_pusheen);
        iv_no_searchresults_pusheen.setBackgroundResource(R.drawable.pusheen_computer_animation1);
        AnimationDrawable frameAnimation = (AnimationDrawable) iv_no_searchresults_pusheen.getBackground();

        // Start the animation (looped playback by default).
        frameAnimation.start();

        btn_back_to_search = (Button) findViewById(R.id.btn_back_to_search);
        btn_back_to_search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                goBackToMainActivity();
            }
        });
    }

    private void goBackToMainActivity() {
        finish();
    }

    private void showKanjiActivity(Kanji kan) {
        Intent intent = new Intent(this, ShowKanjiActivity.class);
        intent.putExtra(ShowKanjiActivity.KANJI_EXTRA, kan);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
    }
}
