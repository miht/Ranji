package ranji.lesu0022.student.umu.se.ranji.Activities;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.ListViewCompat;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;

import com.wdullaer.swipeactionadapter.SwipeActionAdapter;
import com.wdullaer.swipeactionadapter.SwipeDirection;

import ranji.lesu0022.student.umu.se.ranji.Adapters.KanjiAdapter;
import ranji.lesu0022.student.umu.se.ranji.Adapters.StudylistAdapter;
import ranji.lesu0022.student.umu.se.ranji.Data.Kanji;
import ranji.lesu0022.student.umu.se.ranji.Data.Structs;
import ranji.lesu0022.student.umu.se.ranji.KanjiDatabaseHelper;
import ranji.lesu0022.student.umu.se.ranji.R;

/**
 * Created by leifthysellsundqvist on 2017-08-16.
 *
 * This is the activity that shows a list of all the kanji within a selected study list.
 * the user may also play the quiz game with the kanji within this list, if it contains at least 5 kanji.
 *
 * in the future, the user shall also be able to add kanji from this view by searching and then adding.
 */

public class KanjiListActivity extends AppCompatActivity {

    public static final String CURRENT_STUDYLIST_EXTRA = "Current_studylist_extra";

    private KanjiDatabaseHelper db;
    private ListView lv_kanjis;

    private KanjiAdapter mKanjiAdapter;
    private SwipeActionAdapter mAdapter;

    private String currentStudylist = "";

    private ImageView iv_no_kanjis_pusheen;

    private Button iv_no_kanjis_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kanjilist);

        db = KanjiDatabaseHelper.getInstance(this);

        Intent i = getIntent();
        currentStudylist = i.getStringExtra(CURRENT_STUDYLIST_EXTRA);
        setTitle(currentStudylist);

        Cursor cur  = db.fetchKanjiWithinStudylist(currentStudylist);
        mKanjiAdapter = new KanjiAdapter(this, cur);

        initListView();
        initEmptyView();
        initSwipeActionAdapter();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.kanjilists_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.action_add_kanji:

                //TODO add kanji from here as well

                DialogFragment newFragment = Structs.AlertDialogFragment.newInstance("Whoops", "This feature hasn't been implemented yet. If you want to add kanji, you'll have to do it from the main menu.");
                newFragment.show(getSupportFragmentManager(), "dialog");
                break;
            case R.id.action_play:
                play();
                break;
            default:
                return super.onOptionsItemSelected(item);
        }
        return true;
    }

    private void initSwipeActionAdapter() {

        mAdapter = new SwipeActionAdapter(mKanjiAdapter);
        mAdapter.setListView(lv_kanjis);
        lv_kanjis.setAdapter(mAdapter);
        mAdapter.setFarSwipeFraction(1);

        // Set backgrounds for the swipe directions
        mAdapter.addBackground(SwipeDirection.DIRECTION_NORMAL_LEFT,R.layout.row_bg_left_far);

        // Listen to swipes
        mAdapter.setSwipeActionListener(new SwipeActionAdapter.SwipeActionListener(){
            @Override
            public boolean hasActions(int position, SwipeDirection direction){
                if(direction.isLeft()) return true; // Change this to false to disable left swipes
                return false;
            }

            @Override
            public boolean shouldDismiss(int position, SwipeDirection direction){
                // Only dismiss an item when swiping normal left
                return direction == SwipeDirection.DIRECTION_NORMAL_LEFT;
            }

            @Override
            public void onSwipe(int[] positionList, SwipeDirection[] directionList){
                for(int i=0;i<positionList.length;i++) {
                    SwipeDirection direction = directionList[i];
                    int position = positionList[i];
                    String dir = "";

                    switch (direction) {
                        case DIRECTION_NORMAL_LEFT:
                            dir = "Far left";
                            mKanjiAdapter.getCursor().moveToPosition(position);
                            db.removeKanji(currentStudylist,mKanjiAdapter.getCursor().getString(0) );
                            mKanjiAdapter.changeCursor(db.fetchKanjiWithinStudylist(currentStudylist));
                            mKanjiAdapter.notifyDataSetChanged();
                            break;
                    }
                    mAdapter.notifyDataSetChanged();
                }
            }
        });
    }

    private void initListView() {
        lv_kanjis = (ListView) findViewById(R.id.lv_kanjis);

        SwipeActionAdapter mAdapter = new SwipeActionAdapter(mKanjiAdapter);

        mAdapter.setListView(lv_kanjis);

        lv_kanjis.setAdapter(mAdapter);

        lv_kanjis.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Kanji kan = new Kanji(mKanjiAdapter.getCursor().getString(0),
                        mKanjiAdapter.getCursor().getString(1),
                        mKanjiAdapter.getCursor().getString(2),
                        mKanjiAdapter.getCursor().getString(3));

                showKanjiActivity(kan);
            }
        });
        lv_kanjis.setEmptyView(findViewById(R.id.ll_no_kanjis));
    }

    public void initEmptyView() {
        iv_no_kanjis_pusheen = (ImageView) findViewById(R.id.iv_no_kanjis_pusheen);
        iv_no_kanjis_pusheen.setBackgroundResource(R.drawable.pusheen_detective_animation2);
        AnimationDrawable frameAnimation = (AnimationDrawable) iv_no_kanjis_pusheen.getBackground();
        iv_no_kanjis_button = (Button) findViewById(R.id.btn_add_kanji_if_no_kanji);
        iv_no_kanjis_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DialogFragment newFragment = Structs.AlertDialogFragment.newInstance("Whoops", "This feature hasn't been implemented yet. If you want to add kanji, you'll have to do it from the main menu.");
                newFragment.show(getSupportFragmentManager(), "dialog");
            }
        });

        // Start the animation (looped playback by default).
        frameAnimation.start();
    }

    public void showKanjiActivity(Kanji kan) {
        Intent intent = new Intent(this, ShowKanjiActivity.class);
        intent.putExtra(ShowKanjiActivity.KANJI_EXTRA, kan);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
    }

    public void play() {
        if(lv_kanjis.getChildCount() < 5) {
            //Structs.generatePopup(this, "Error", "A list must contain at least 5 kanji before you can play it.");
            DialogFragment newFragment = Structs.AlertDialogFragment.newInstance("Error", "A list must contain at least 5 kanji before you can play it.");
            newFragment.show(getSupportFragmentManager(), "dialog");
        }
        else {
            goToPlayActivity();
        }

    }

    public void goToPlayActivity() {
        Intent intent = new Intent(this, GameActivity.class);
        intent.putExtra(GameActivity.GAME_STUDYLIST_EXTRA, currentStudylist);
        startActivity(intent);
    }
}
